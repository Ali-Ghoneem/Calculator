let display = document.getElementById('display');
let history = document.getElementById('history');
let currentInput = '';
let historyArray = [];
let historyVisible = true;

document.querySelectorAll('.btn').forEach(button => {
    button.addEventListener('click', () => {
        const value = button.innerText;

        if (value === 'C') {
            currentInput = '';
            display.innerText = '0';
        } else if (value === 'DEL') {
            currentInput = currentInput.slice(0, -1);
            display.innerText = currentInput || '0';
        } else if (value === '=') {
            try {
                const result = eval(currentInput);
                historyArray.push(`${currentInput} = ${result}`);
                history.innerText = historyArray.join('\n');
                display.innerText = result;
                currentInput = '';
            } catch {
                display.innerText = 'Error';
            }
        } else if (value === 'Show History') {
            historyVisible = !historyVisible;
            history.style.display = historyVisible ? 'block' : 'none';
        } else if (value === 'Clear History') {
            historyArray = [];
            history.innerText = '';
        } else {
            currentInput += value;
            display.innerText = currentInput;
        }
    });
});